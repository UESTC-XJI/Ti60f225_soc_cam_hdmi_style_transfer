"""候选网络结构。

所有架构都返回 NetSpec，形状由 Builder 在构建期算好。
"""

from __future__ import annotations

from collections.abc import Callable

from .spec import Builder, NetSpec


def fns(
    height: int = 480,
    width: int = 640,
    mult: float = 0.25,
    nres: int = 5,
    head: int = 9,
    tail: int = 9,
    ci: int = 3,
    co: int = 3,
) -> NetSpec:
    """Johnson et al. Fast Neural Style 的标准结构（PyTorch examples 版本）。

    结构：
        9x9 conv -> /2 -> /2 -> N x ResidualBlock(@1/4 res)
        -> upsample x2 + conv -> upsample x2 + conv -> 9x9 conv

    mult   : 通道缩放系数。1.0 = 原版 32/64/128，0.25 = 官方提示的"1/4 通道"。
    nres   : 残差块数量（原版 5）。
    head/tail : 首尾卷积核尺寸（原版 9；赛题只要求 3x3 或 5x5）。
    ci/co  : 输入/输出通道。**ci=co=1 就是亮度域（Y-only）**——网络只学明暗，
             颜色由内容图原样接回。对应 `train/model.py` 的 `改D-Y`。
    """
    c = lambda base: max(1, round(base * mult))

    b = Builder(
        name=f"FNS 1/{round(1 / mult)}ch {nres}res {head}/{tail}"
             + (" 亮度域" if ci == 1 and co == 1 else ""),
        hin=height, win=width, cin=ci,
    )
    b.conv(c(32), k=head, stride=1, name="enc1")
    b.conv(c(64), k=3, stride=2, name="enc2")
    b.conv(c(128), k=3, stride=2, name="enc3")
    for i in range(nres):
        b.residual_block(f"res{i + 1}")
    b.upsample(2, name="up1")
    b.conv(c(64), k=3, name="dec1")
    b.upsample(2, name="up2")
    b.conv(c(32), k=3, name="dec2")
    b.conv(co, k=tail, stride=1, name="out", norm="")
    b.spec.cout = co
    return b.spec


def lowres_domain(
    height: int = 480,
    width: int = 640,
    ch: int = 32,
    nres: int = 2,
    down: int = 4,
    pre_k: int = 5,
) -> NetSpec:
    """全程在 1/down 分辨率域运算，末尾用 subpixel 卷积一次上采样回原尺寸。

    优势是算力随输入像素数线性伸缩（不像 FNS 那样在 1/4 分辨率上堆 10 个卷积），
    在 640x480@15fps 下余量最大。代价是高频细节变软。

    注意：720p@30 的像素率是 640x480@15 的 **6 倍**，本架构在基准时序假设下
    依然到不了 720p30（约 280%），别被"1/4 分辨率"误导——内部域尺寸随输入一起放大。
    """
    b = Builder(
        name=f"1/{down}分辨率域 {ch}ch {nres}res subpix",
        hin=height, win=width, cin=3,
    )
    b.down(down, name="preproc")   # 640x480 -> 160x120，无乘法
    b.conv(ch, k=pre_k, stride=1, name="pre")
    for i in range(nres):
        b.residual_block(f"res{i + 1}")
    b.conv(ch, k=3, stride=1, name="head")
    b.subpix(3, r=down, k=3, name="subpix")
    b.spec.cout = 3
    return b.spec


def dw_separable(
    height: int = 480,
    width: int = 640,
    ch: int = 32,
    nres: int = 3,
    down: int = 2,
) -> NetSpec:
    """深度可分离版本：算力最省，但 depthwise 在 FPGA 上算术强度极低，
    每个 MAC 仍要占一个 DSP 通道，DSP 利用率会很难看。仅作对照。"""
    b = Builder(
        name=f"深度可分离 1/{down}res {ch}ch {nres}blk",
        hin=height, win=width, cin=3,
    )
    b.down(down, name="preproc")
    b.conv(ch, k=3, stride=1, name="pre")
    for i in range(nres):
        b.depthwise(3, name=f"dw{i + 1}")
        b.conv(ch, k=1, stride=1, name=f"pw{i + 1}")
    b.subpix(3, r=down, k=3, name="subpix")
    b.spec.cout = 3
    return b.spec


# ---- 预置候选集 ----
# 用"工厂"而不是"实例"：同一个架构要在 640x480 和 1280x720 两种输入尺寸下分别构建。
# 直接复用同一个 NetSpec 去评估不同分辨率是错的——它内部尺寸已经固化了。
CandidateFactory = Callable[[int, int], NetSpec]


def candidate_factories() -> dict[str, CandidateFactory]:
    """你 doc 里的主推路线 + 几条能跑通的替代路线。

    返回 (height, width) -> NetSpec 的工厂函数，供 sweep 按目标分辨率分别构建。
    """
    return {
        "现状: 1/4ch 5res 9x9": lambda h, w: fns(h, w, mult=0.25, nres=5, head=9, tail=9),
        "改A: 1/4ch 3res 3x3": lambda h, w: fns(h, w, mult=0.25, nres=3, head=3, tail=3),
        "改B: 1/4ch 2res 3x3": lambda h, w: fns(h, w, mult=0.25, nres=2, head=3, tail=3),
        "改C: 1/4分辨率域 32ch 2res":
            lambda h, w: lowres_domain(h, w, ch=32, nres=2, down=4),
        "改C': 1/4分辨率域 32ch 3res":
            lambda h, w: lowres_domain(h, w, ch=32, nres=3, down=4),
        "改D: 1/8ch 3res 3x3": lambda h, w: fns(h, w, mult=0.125, nres=3, head=3, tail=3),
        # ⚠ 这个键 2026-09-29 才补上。在那之前 `train/parity.py` 遍历 BUILDERS 时
        # 会在这里 KeyError 崩掉——前四个 [OK] 之后直接异常，等于验收守卫长期失效。
        # 与 `train/model.py::BUILDERS` 的同名项必须逐字对应。
        "改D-Y: 1/8ch 3res 3x3 亮度域":
            lambda h, w: fns(h, w, mult=0.125, nres=3, head=3, tail=3, ci=1, co=1),
        "对照: 全通道 5res 9x9": lambda h, w: fns(h, w, mult=1.0, nres=5, head=9, tail=9),
        "对照: 深度可分离 1/2res":
            lambda h, w: dw_separable(h, w, ch=32, nres=3, down=2),
    }


def candidates(height: int = 480, width: int = 640) -> dict[str, NetSpec]:
    """在指定输入尺寸下构建全部候选网络。"""
    return {n: make(height, width) for n, make in candidate_factories().items()}
