# FPGA 风格迁移 — 模型与成本模型打包

> 2026 全国大学生嵌入式芯片与系统设计竞赛 FPGA 赛道赛题一
> Ti60F225I3-V4 板 · Fast Neural Style 实时风格化

## 目录结构

```
├── stnet/                  # stnet 成本模型（Python，预算/架构选型用）
│   ├── archs.py            #   网络架构定义
│   ├── costmodel.py        #   资源/算力成本估算
│   ├── hw.py               #   硬件映射（rowpipe 行缓冲流水）
│   └── spec.py             #   规格参数
│
├── weights/                # 训练权重（PyTorch 部署版 net_deploy.pt）
│   ├── D_sw1e5/            #   当前工程实际用的风格（最终部署）
│   ├── D_ukiyoe/           #   浮世绘风格
│   └── D_wc_g15/           #   水彩风格
│
└── rtl_vectors/            # RTL 实际烧录用的权重向量（hex）
    ├── L0.w / L0.b         #   enc1 权重/偏置（b' 已含 int8 偏移修正）
    ├── L0.qm / L0.qo       #   requant 参数（scale/零点/裁剪）
    └── L0*_rom.hex         #   style_wload 装载器读的 ROM 文件
```

## 训练数据来源（未打包，~420 MB）

数据太大未包含在本包内，来源如下，可自行下载：

| 数据 | 大小 | 来源 |
|------|------|------|
| `content/` 内容图（800 张） | 124 MB | **COCO val2017** — `http://images.cocodataset.org/zips/val2017.zip`<br>（Fast Neural Style 论文用的同一批数据） |
| `styles/` 风格图（8 张） | 5.4 MB | **Wikimedia Commons**（通过 Commons API 按文件名解析 URL 下载） |
| `styles_ukiyoe/` 浮世绘 | 3.7 MB | 同上（浮世绘画作） |
| `styles_watercolor/` 水彩 | 3.2 MB | 同上（水彩画作） |
| `teacher_paprika/` 教师输出（800 张） | 247 MB | AnimeGAN2 paprika 模型推理产出（`sim/models/animegan2_paprika.pt`，8.2 MB） |
| `video/` 测试视频 | 37 MB | 本地测试素材 |

下载脚本：`sim/train/fetch_data.py`（用 curl，因国内网络 urllib 连 Wikimedia 会断）。

## 关键事实

- 网络：Fast Neural Style，12 层 = enc×3 + res×6 + dec×2 + out
- 当前板上只铺了 **enc1（3→4 通道）**，其余 10 层待铺
- 当前工程用权重：`weights/D_sw1e5/deploy/net_deploy.pt`（对应 `rtl_vectors/L0*`）
- 芯片：Ti60F225（62,016 LE / 160 DSP / 256 RAM）
- 加速器：rowpipe 行缓冲流水，PIX=8 / CO=4 / 挂 hdmi_tx_slow_clk 148.5 MHz
