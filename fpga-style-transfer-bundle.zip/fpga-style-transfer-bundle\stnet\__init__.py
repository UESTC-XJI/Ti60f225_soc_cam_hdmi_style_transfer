"""风格迁移网络 FPGA 部署的仿真与成本建模。

模块划分：
    hw        —— Ti60F225 硬件预算常量（改这里能重算全套结论）
    spec      —— 网络结构描述（层、形状、参数量、MAC）
    archs     —— 候选网络架构
    costmodel —— 折算成算力/存储/带宽并给出可行性判决
"""

from .hw import (
    BASIC,
    DEFAULT_BUDGET,
    DEFAULT_TIMING,
    HIGH,
    TARGETS,
    Budget,
    Timing,
    budget_after,
)
from .spec import Builder, Layer, NetSpec
from .archs import (
    CandidateFactory,
    candidate_factories,
    candidates,
    dw_separable,
    fns,
    lowres_domain,
)
from .costmodel import Report, analyze, sweep, table_header

__all__ = [
    "BASIC", "HIGH", "TARGETS", "Budget", "Timing",
    "DEFAULT_BUDGET", "DEFAULT_TIMING", "budget_after",
    "Builder", "Layer", "NetSpec",
    "CandidateFactory", "candidate_factories", "candidates",
    "fns", "lowres_domain", "dw_separable",
    "Report", "analyze", "sweep", "table_header",
]
