"""Ti60F225 硬件预算常量。

数据来源：
  - Efinix Ti60 Data Sheet v2.7 Table 1/2（docs/Ti60-DataSheet-v2.7-en.pdf p.4, p.8）
  - 各 IP 官方 User Guide 的资源占用表
  - **2026-09-25 新增**：赛题板参考设计包（G:\\FPGAtest\\demoboard\\）里 Efinity
    真实跑出来的 `.res.csv` 资源报告 —— 见 INFRASTRUCTURE_MEASURED

**这个文件是整个成本模型的"电源开关"**：改这里的数字就能重算全套结论。
所有成本模型都从这里取值，**不要在别处硬编码资源数字**。

---
给零基础读者：这个文件里反复出现的三个名词是 FPGA 的三种"资源"，可以类比成
造房子时的三种材料。把芯片想成一个固定大小的地块，你要在里面盖一栋叫
"加速器"的楼，但**公共设施（水电气、物业）必须先占掉一部分地**：

    LE    (Logic Element)   "通用逻辑单元"——最基础的可编程门电路，
                            谁都能用，但做乘法这种活特别费（要几百个才顶一个乘法器）
    BRAM  (Block RAM)       "片上存储块"——芯片自带的仓库，共 256 块，
                            每块存 10 Kbit（= 1.25 KB）。行缓冲、权重都放这里
    DSP   (Digital Signal   "专用乘法器"——专门干乘法累加的硬电路。
           Processor)       做 1 次乘加，用 DSP 只花 1 个周期；
                            用 LE 搭要几十个 LE + 好几级延迟

成本模型关心的就一件事：**扣掉公共设施之后，加速器还剩多少地。**
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Block:
    """一块占资源的 IP（知识产权核 = 别人写好、你直接例化的功能模块）。

    frozen=True 的意思是"这个对象一旦造出来就不能被修改"。这样做是为了防止
    某处代码不小心改掉一个共享常量，导致别处的结论莫名变化——这类 bug 极难查。

    三个字段对应上面说的三种资源：
        le   —— 消耗多少通用逻辑单元
        bram —— 消耗多少块 10-Kbit 存储块
        dsp  —— 消耗多少个乘法器
    """

    name: str
    le: int
    bram: int  # 10-Kbit 存储块数量
    dsp: int


# ---- 芯片总量（Data Sheet Table 1，Ti60 全系列）----
# 这三个数是"地块总面积"，后面所有预算都从这里往下扣。
CHIP_LE = 62_016
CHIP_BRAM = 256  # 个 10-Kbit 块
CHIP_DSP = 160

# 每个 10-Kbit 存储块 = 10240 bit = 1280 字节 = 1.25 KB
# 下面两行之所以写成算式而不是直接写 1280，是为了让"这个数怎么来的"一目了然。
BYTES_PER_BRAM = 10 * 1024 // 8  # 1280 字节（// 是整除，丢掉余数）
KB_PER_BRAM = BYTES_PER_BRAM / 1024  # 1.25 KB


# ═══════════════════════════════════════════════════════════════════════
# 基础设施 IP —— 必须先扣掉的"公共设施"
# ═══════════════════════════════════════════════════════════════════════
#
# 【口径一】手册/官方表口径（当前默认值）
#
# ⚠ 本项目在这里踩过一个坑：早期只减了 Sapphire，漏了 CSI-2 和 DDR3 控制器，
#    算出"加速器可用 190KB"。正确做法是把**每一个**系统 IP 都扣掉。
#    详见 ti60-resources.md 与 memory/ti60-accelerator-budget-correction.md。
#
# 注意这里**不含 RISC-V**——它按核数查 SAPPHIRE_BY_CORES，不在这张表里。
INFRASTRUCTURE: tuple[Block, ...] = (
    Block("MIPI CSI-2 RX Controller", le=3_678, bram=11, dsp=0),
    Block("DDR3 Soft Controller", le=2_300, bram=27, dsp=0),
)

# 【口径二】实测口径（2026-09-25，赛题板参考设计包真实综合结果）
#
# 三个数都跟手册口径不一样，其中 HDMI TX 是**原来根本没扣的那一项**：
#
#   HDMI TX 软 RTL  bram=2    —— 实测（02_hdmi_demo 的 dvi_encoder_m0）。
#                                赛题板的 HDMI 是纯 RTL（dvi_encoder + serdes_10_to_1
#                                + ddio_out4），不是硬核 IP，所以占用很小。
#   DDR3 控制器     bram=22   —— 实测（02_hdmi_demo、08_soc_demo 两处一致）。
#                                手册口径的 27 是从 Ti180 外推的，偏大。
#   CSI-2 RX        bram=17   —— 实测（4-lane loopback 工程）。
#                                但同一个 IP 在 oob 工程里是 36 块，差别在
#                                PIXEL_FIFO_DEPTH 这个可配参数（4096 很深）。
#                                **它是本项目最灵活的预算旋钮**，所以这里给 17。
INFRASTRUCTURE_MEASURED: tuple[Block, ...] = (
    Block("MIPI CSI-2 RX Controller", le=3_678, bram=17, dsp=0),
    Block("DDR3 Soft Controller", le=2_300, bram=22, dsp=0),
    Block("HDMI TX (软 RTL)", le=700, bram=2, dsp=0),
)

# ---- Sapphire SoC：按核数查表，**不能按"每核多少块"线性外推** ----
#
# 数据来源：Efinix Sapphire IP 产品页的 "Ti60F225 C4 / Cached SoC with External
# Memory（Standard Option）" 表。1 核那一行就是表里的 "typical" 配置。
#
# ⚠ 本项目在这里踩过第二个坑：曾经用 "3 核 127 块 ÷ 3 ≈ 每核 42 块" 去推 1 核，
#    算出 42 块。**这是错的**——官方表里 1 核是 56 块。原因见下面 budget_after 的注释。
SAPPHIRE_BY_CORES: dict[int, Block] = {
    1: Block("RISC-V Sapphire 1 核", le=7_560, bram=56, dsp=4),
    2: Block("RISC-V Sapphire 2 核", le=14_009, bram=103, dsp=8),
    3: Block("RISC-V Sapphire 3 核", le=18_821, bram=127, dsp=12),
    4: Block("RISC-V Sapphire 4 核", le=22_078, bram=150, dsp=16),
}

# ---- 单核占用还有第二个口径：真实工程实测值 ----
#
# 官方产品页的 1 核 "typical"：                      56 块
# 参考设计包里真实综合出的 SoC（08_soc_demo）：      43 块
#
# **差 13 块 = 16.25 KB，足以改变 720p 方案的成败**，所以两个都留着做敏感度分析。
# 默认用官方值（更保守）；等自己在 Efinity 里综合出 1 核 SoC 之后，用实测值重算一遍。
SAPPHIRE_1CORE_BRAM_OFFICIAL = SAPPHIRE_BY_CORES[1].bram  # 56
SAPPHIRE_1CORE_BRAM_MEASURED = 43


@dataclass(frozen=True)
class Budget:
    """留给风格迁移加速器的资源（= 芯片总量 − 所有基础设施 IP）。

    注意这是**一个静态快照**，不是"实时的剩余量"。
    """

    le: int
    bram: int
    dsp: int

    @property
    def bram_kb(self) -> float:
        """把 BRAM 块数换算成 KB。@property 装饰器让我们可以像读字段一样
        写 `budget.bram_kb`，而不用写成 `budget.bram_kb()`——读起来更像一句人话。"""
        return self.bram * KB_PER_BRAM

    def __str__(self) -> str:
        """定义 print(budget) 时显示什么。"""
        return f"{self.le} LE / {self.bram} BRAM ({self.bram_kb:.1f}KB) / {self.dsp} DSP"


def budget_after(
    use_riscv_cores: int = 3,
    use_ddr3: bool = True,
    measured: bool = False,
    sapphire_1core_bram: int = SAPPHIRE_1CORE_BRAM_OFFICIAL,
) -> Budget:
    """扣除基础设施 IP 后剩余的加速器资源。

    参数（都可调，用来做"敏感度分析"——即"某个假设变一点，结论会不会翻盘"）：
        use_riscv_cores      RISC-V 软核用几个（1~4）。**这是本项目最关键的一个旋钮**，
                             因为核数直接决定 BRAM 预算，而 720p 方案卡的就是 BRAM。
        use_ddr3             是否用 DDR3 控制器（关掉它结果不真实，仅供对照）
        measured             True 用实测口径，False 用手册口径（见上面两个常量）
        sapphire_1core_bram  单核时 Sapphire 占多少块。官方 56 / 实测 43，见上面常量的说明。

    返回：一个 Budget 对象。

    ---
    给零基础读者：这个函数就是"从总量里减掉公共设施"。
    可以理解成 `剩余 = 总面积 − Σ(每个设施占的面积)`。唯一的复杂点在于
    RISC-V 核数是个变量——用 1 个核比用 3 个核省下大量 BRAM，而省下的
    BRAM 正是能否跑高分辨率的关键。
    """
    # 先假设一块地都没被占，然后逐个设施往下扣。
    le, bram, dsp = CHIP_LE, CHIP_BRAM, CHIP_DSP

    # ---- 第 1 步：扣 RISC-V，按核数查表 ----
    #
    # ⚠ 这里曾经写成 `bram -= 42`（= 把 3 核的 127 块除以 3），是**错的**。
    #   官方表里 1 核是 56 块，真实工程实测 43 块，都不是 42。
    #
    #   为什么"每核平均"不成立：SoC 里有一大块是**各核共享的**（缓存、总线、
    #   中断控制器、外设），不随核数线性增长。所以核数越少，每核摊到的就越多。
    #   看表就明白了：127→103→56，从 3 核到 2 核每核省 24 块，
    #   从 2 核到 1 核却省掉 47 块。
    if use_riscv_cores not in SAPPHIRE_BY_CORES:
        raise ValueError(
            f"RISC-V 核数只能是 {sorted(SAPPHIRE_BY_CORES)}，收到 {use_riscv_cores}"
        )
    sapphire = SAPPHIRE_BY_CORES[use_riscv_cores]
    if use_riscv_cores == 1 and sapphire_1core_bram != sapphire.bram:
        # 允许覆盖单核数字，用于在"官方 56 / 实测 43"之间做敏感度分析。
        sapphire = Block(sapphire.name, sapphire.le, sapphire_1core_bram, sapphire.dsp)
    le -= sapphire.le
    bram -= sapphire.bram
    dsp -= sapphire.dsp

    # ---- 第 2 步：扣其余基础设施 ----
    for b in (INFRASTRUCTURE_MEASURED if measured else INFRASTRUCTURE):
        if b.name.startswith("DDR3") and not use_ddr3:
            continue  # 关掉 DDR3 只是做对照，真实方案里必须有它
        le -= b.le
        bram -= b.bram
        dsp -= b.dsp

    return Budget(le=le, bram=bram, dsp=dsp)


# ---- DSP 能力（Data Sheet p.8）----
# Normal: 1×19x18 | Dual: 1×11x10 + 1×8x8 | Quad: 1×7x6 + 3×4x4 | Float: BFLOAT16 FMA
#
# 关键推断：Dual 模式的 11x10 和 8x8 两个乘法器都能容纳 8x8 有符号乘法，
# 因此 W8A8（INT8 权重 × INT8 激活）下每个 DSP 每时钟可完成 2 个 MAC。
# 这是本模型最重要的一个假设，已对照 Data Sheet 原文核实。若改用 Quad + 低比特权重
# 还能再翻，但画质风险大，暂不建模。
#
# 给零基础读者：普通 FPGA 里 DSP 就是"一个硬核乘法器"，一次算一个乘法。
# 但 Ti60 的 DSP 可以切成"双通道"模式，变成两个小一点的乘法器同时工作。
# 神经网络量化到 8 位之后，乘法只需要 8 位宽，两个小乘法器都够用——
# 于是"一个 DSP 干两个乘法"，算力直接翻倍。**这是本项目能跑起来的前提。**
INT8_MAC_PER_DSP = 2


@dataclass(frozen=True)
class Timing:
    """加速器的时序/效率假设。改这里可对结论做敏感度分析。

    三个字段：
        clk_hz       时钟频率。数字里的 `200e6` 是科学计数法 = 200×10⁶ = 200 MHz。
        utilization  利用率。理论峰值算力永远用不满（要等数据、要处理边界），
                     实际能达到的比例叫利用率。65% 是经验值，不是物理极限。
        mac_per_dsp  每个 DSP 每周期能做几次乘加（见上面 INT8_MAC_PER_DSP）。
    """

    clk_hz: float = 200e6
    utilization: float = 0.65  # DSP 阵列实际利用率
    mac_per_dsp: int = INT8_MAC_PER_DSP

    def peak_mac_s(self, dsp: int) -> float:
        """给定额定 DSP 数，INT8 MAC/s 天花板。

        公式：峰值 = 乘法器个数 × 每个每周期几次 × 每秒多少周期 × 利用率
        单位 MAC/s 读作"每秒多少次乘加"。
        """
        return dsp * self.mac_per_dsp * self.clk_hz * self.utilization

    def describe(self, dsp: int) -> str:
        """把这个假设打印成人话，方便在报告里核对。"""
        # 下面这一长串是 f-string：{} 里的表达式会被求值后填进字符串。
        # 例如 {self.clk_hz / 1e6:.0f} 表示"频率除以一百万，保留 0 位小数"。
        return (f"{dsp} DSP × {self.mac_per_dsp} MAC/DSP × {self.clk_hz / 1e6:.0f}MHz "
                f"× {self.utilization:.0%} = {self.peak_mac_s(dsp) / 1e9:.1f} GMAC/s")


# ---- 赛题指标要求 ----
@dataclass(frozen=True)
class Target:
    """赛题要求的分辨率/帧率组合。

    基础分和高阶分是**两个不同的目标**，成本模型必须分别评估——
    因为每帧的计算量随像素数变化，两个目标的账完全不同。
    """

    name: str
    width: int
    height: int
    fps: float

    @property
    def pixels_per_sec(self) -> float:
        """每秒要处理多少像素。这个数决定了需要多少算力。"""
        return self.width * self.height * self.fps

    @property
    def pixels(self) -> int:
        """一帧多少像素。"""
        return self.width * self.height


BASIC = Target("基础 640x480@15", 640, 480, 15)
HIGH = Target("高阶 1280x720@30", 1280, 720, 30)

TARGETS: tuple[Target, ...] = (BASIC, HIGH)


# ---- 默认实例 ----
# 其它模块 import 这两个就够了，不用每次自己构造。
# 注意 `budget_after()` 不传参 = 手册口径 + 3 核。想用实测口径就传 measured=True。
DEFAULT_BUDGET = budget_after()
DEFAULT_TIMING = Timing(
    clk_hz=200e6,
    utilization=0.65,
    mac_per_dsp=INT8_MAC_PER_DSP,
)
