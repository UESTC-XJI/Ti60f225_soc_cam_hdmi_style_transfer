"""网络结构描述：层、形状推导、参数量与 MAC 统计。

设计要点：**空间尺寸在构建期就算好并固化到每一层上**，成本模型只读 layer.hout/wout，
不再自己推导 stride。这样就不会重演"encoder 第三层 stride 算错导致 MAC 少算 7%"的坑。
"""

from __future__ import annotations

from dataclasses import dataclass, field


# ---- 层类型 ----
CONV = "conv"        # 标准卷积（含 1x1）
DW = "dw"            # 深度可分离卷积的 depthwise 部分
SUBPIX = "subpix"    # ci -> co*r^2 卷积 + pixel shuffle 上采样
UP = "up"            # 最近邻上采样（无参数）
DOWN = "down"        # 降采样（抽点/平均，无乘法）
ADD = "add"          # 残差逐元素相加（无参数）
ACT = "act"          # ReLU / IN 等逐元素算子（无参数，仅占位置）


@dataclass(frozen=True)
class Layer:
    """一层算子。空间尺寸显式存储，不推导。"""

    name: str
    kind: str
    ci: int = 0
    co: int = 0
    k: int = 0
    stride: int = 1
    hin: int = 0
    win: int = 0
    hout: int = 0
    wout: int = 0
    # 该层输出上是否跟随实例归一化（决定硬件要不要算统计量）
    norm: str = ""          # "" | "in" | "bn" | "in_folded"
    note: str = ""

    # ---------- 派生量 ----------
    @property
    def params(self) -> int:
        if self.kind == CONV:
            return self.ci * self.co * self.k * self.k + self.co
        if self.kind == DW:
            return self.ci * self.k * self.k + self.ci
        if self.kind == SUBPIX:
            return self.ci * self.cout_conv * self.k * self.k + self.cout_conv
        return 0

    @property
    def macs(self) -> int:
        """乘累加次数（1 MAC = 2 FLOP）。"""
        if self.kind == CONV:
            return self.ci * self.co * self.k * self.k * self.hout * self.wout
        if self.kind == DW:
            return self.ci * self.k * self.k * self.hout * self.wout
        if self.kind == SUBPIX:
            # 关键：subpixel 卷积在**低分辨率**上完成，只有 pixel shuffle 是无算力的。
            # 所以算力按输入像素数 hin*win 计，不是 hout*wout。
            return self.ci * self.cout_conv * self.k * self.k * self.hin * self.win
        return 0

    @property
    def cout_conv(self) -> int:
        """SUBPIX 层实际卷积输出的通道数 = co * r^2。"""
        if self.kind != SUBPIX or self.hin <= 0:
            return self.co
        r = self.hout // self.hin
        return self.co * r * r

    @property
    def pixel_scale(self) -> int:
        """SUBPIX 的上采样倍率。"""
        return self.hout // self.hin if self.hin else 1

    @property
    def linebuf_bytes(self) -> int:
        """行流水线所需行缓冲（INT8，输入侧）。"""
        if self.kind not in (CONV, DW, SUBPIX) or self.k <= 1:
            return 0
        return (self.k - 1) * self.win * self.ci

    def __str__(self) -> str:
        tag = f"{self.ci}->{self.co}" if self.kind in (CONV, DW, SUBPIX) else self.kind
        geo = f"{self.hin}x{self.win}->{self.hout}x{self.wout}"
        return f"{self.name:<22} {self.kind:<6} {tag:<12} k={self.k} {geo}"


@dataclass
class NetSpec:
    """一个完整的网络。"""

    name: str
    layers: list[Layer] = field(default_factory=list)
    hin: int = 0
    win: int = 0
    cin: int = 3
    cout: int = 3
    note: str = ""

    # ---------- 汇总 ----------
    @property
    def params(self) -> int:
        return sum(l.params for l in self.layers)

    @property
    def macs_per_frame(self) -> int:
        return sum(l.macs for l in self.layers)

    @property
    def weight_bytes_int8(self) -> float:
        """INT8 权重字节数（偏置按 INT32 算，占比极小）。"""
        w = sum(l.params for l in self.layers)
        return w  # 1 字节/参数

    @property
    def weight_kb_int8(self) -> float:
        return self.weight_bytes_int8 / 1024

    @property
    def linebuf_bytes(self) -> int:
        """全展开行流水的行缓冲上界（所有层同时活跃）。

        注意这是**上界**：分条带/时分复用的微架构能显著降低，但不能低于
        单层最大值。两个数都报出来，便于判断。
        """
        return sum(l.linebuf_bytes for l in self.layers)

    def residual_delay_bytes(self) -> int:
        """残差块恒等通路的延迟线：需要把输入特征图延迟两个卷积的深度。

        行流水线中"两个卷积的深度"≈ 2 行（每个 3x3 卷积贡献 1 行延迟）。
        """
        total = 0
        for i, l in enumerate(self.layers):
            if l.kind == ADD:
                # 找该 add 对应的卷积层（往前最近的 conv），按其输入尺寸估算
                for j in range(i - 1, -1, -1):
                    p = self.layers[j]
                    if p.kind in (CONV, DW):
                        total += 2 * p.win * p.ci
                        break
        return total

    def macs_at(self, fps: float) -> float:
        return self.macs_per_frame * fps

    def layer_table(self) -> str:
        """逐层明细，用于核对和交给 RTL。"""
        rows = [f"{'层':<22} {'类型':<6} {'通道':<12} {'核':<4} {'尺寸':<20} "
                f"{'参数':>9} {'MAC/帧':>12} {'占比':>6}"]
        rows.append("-" * 100)
        total = self.macs_per_frame
        for l in self.layers:
            if l.kind in (UP, DOWN, ADD, ACT):
                rows.append(str(l))
                continue
            rows.append(
                f"{l.name:<22} {l.kind:<6} {l.ci}->{l.co:<8} {l.k}x{l.k:<2} "
                f"{l.hin}x{l.win}->{l.hout}x{l.wout}".ljust(68)
                + f"{l.params:>9,} {l.macs:>12,} {100 * l.macs / total:>5.1f}%"
            )
        rows.append("-" * 100)
        rows.append(f"{'合计':<22} {'':<6} {'':<12} {'':<4} {'':<20}"
                    f"{self.params:>9,} {total:>12,} 100.0%")
        return "\n".join(rows)


class Builder:
    """形状追踪构建器：每加一层就更新当前 (h, w, c)，杜绝 stride 推导错误。"""

    def __init__(self, name: str, hin: int, win: int, cin: int = 3, note: str = ""):
        self.spec = NetSpec(name=name, hin=hin, win=win, cin=cin, note=note)
        self.h, self.w, self.c = hin, win, cin

    # ---- 内部 ----
    def _emit(self, layer: Layer) -> Layer:
        self.spec.layers.append(layer)
        return layer

    # ---- 算子 ----
    def conv(self, co: int, k: int = 3, stride: int = 1, name: str | None = None,
             norm: str = "in", note: str = "") -> Layer:
        """same padding 卷积：hout = ceil(hin/stride)。"""
        ho = (self.h + stride - 1) // stride
        wo = (self.w + stride - 1) // stride
        l = self._emit(Layer(
            name=name or f"conv{len(self.spec.layers)}",
            kind=CONV, ci=self.c, co=co, k=k, stride=stride,
            hin=self.h, win=self.w, hout=ho, wout=wo, norm=norm, note=note,
        ))
        self.h, self.w, self.c = ho, wo, co
        return l

    def depthwise(self, k: int = 3, stride: int = 1, name: str | None = None) -> Layer:
        ho = (self.h + stride - 1) // stride
        wo = (self.w + stride - 1) // stride
        l = self._emit(Layer(
            name=name or f"dw{len(self.spec.layers)}",
            kind=DW, ci=self.c, co=self.c, k=k, stride=stride,
            hin=self.h, win=self.w, hout=ho, wout=wo, norm="", note="",
        ))
        self.h, self.w = ho, wo
        return l

    def act(self, name: str | None = None, norm: str = "") -> Layer:
        """占位：ReLU / 归一化。改前一层记录的 norm 不合适，这里单独记一条。"""
        return self._emit(Layer(
            name=name or f"act{len(self.spec.layers)}", kind=ACT,
            ci=self.c, co=self.c, hin=self.h, win=self.w, hout=self.h, wout=self.w,
            norm=norm,
        ))

    def subpix(self, co: int, r: int = 2, k: int = 3, name: str | None = None) -> Layer:
        """低分辨率上做卷积 -> co*r^2 通道 -> pixel shuffle 到 r 倍分辨率。"""
        ho, wo = self.h * r, self.w * r
        l = self._emit(Layer(
            name=name or f"subpix{len(self.spec.layers)}",
            kind=SUBPIX, ci=self.c, co=co, k=k, stride=1,
            hin=self.h, win=self.w, hout=ho, wout=wo, norm="in",
        ))
        self.h, self.w, self.c = ho, wo, co
        return l

    def residual_block(self, name: str) -> None:
        """标准残差块：conv-IN-ReLU -> conv-IN -> add。"""
        self.conv(self.c, 3, name=f"{name}.c1")
        self.act(f"{name}.act1")
        self.conv(self.c, 3, name=f"{name}.c2")
        self.add(name=f"{name}.add")

    def add(self, name: str | None = None) -> Layer:
        return self._emit(Layer(
            name=name or f"add{len(self.spec.layers)}", kind=ADD,
            ci=self.c, co=self.c, hin=self.h, win=self.w, hout=self.h, wout=self.w,
        ))

    def upsample(self, r: int = 2, name: str | None = None) -> Layer:
        """最近邻上采样（行复制），无参数。"""
        ho, wo = self.h * r, self.w * r
        l = self._emit(Layer(
            name=name or f"up{len(self.spec.layers)}", kind=UP,
            ci=self.c, co=self.c, hin=self.h, win=self.w, hout=ho, wout=wo,
        ))
        self.h, self.w = ho, wo
        return l

    def down(self, r: int = 4, name: str | None = None) -> Layer:
        """输入降采样到 1/r 分辨率域。无乘法（抽点或 2x2 平均）。

        必须显式建模：否则 NetSpec.hin 会变成降采样后的尺寸，
        而成本模型拿到的是"网络输入尺寸"，两者对不上。
        """
        ho, wo = self.h // r, self.w // r
        l = self._emit(Layer(
            name=name or f"down{len(self.spec.layers)}", kind=DOWN,
            ci=self.c, co=self.c, hin=self.h, win=self.w, hout=ho, wout=wo,
        ))
        self.h, self.w = ho, wo
        return l

    @property
    def out_channels(self) -> int:
        return self.c
