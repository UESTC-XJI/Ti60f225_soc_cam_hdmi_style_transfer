"""硬件成本模型：把 NetSpec 折算成 Ti60 上的算力/存储/DDR 开销，并给出可行性判决。"""

from __future__ import annotations

from dataclasses import dataclass

from .hw import Budget, Target, Timing
from .spec import ACT, ADD, DOWN, UP, NetSpec


@dataclass
class Report:
    spec: NetSpec
    target: Target
    budget: Budget
    timing: Timing

    # ---------- 算力 ----------
    @property
    def macs_per_frame(self) -> int:
        return self.spec.macs_per_frame

    @property
    def required_mac_s(self) -> float:
        return self.macs_per_frame * self.target.fps

    @property
    def ceiling_mac_s(self) -> float:
        return self.timing.peak_mac_s(self.budget.dsp)

    @property
    def utilization(self) -> float:
        """需要的算力占硬件天花板的比例。>1 即跑不动。"""
        return self.required_mac_s / self.ceiling_mac_s

    @property
    def compute_ok(self) -> bool:
        return self.utilization <= 1.0

    @property
    def max_fps(self) -> float:
        """算力拉满时能跑到多少帧。"""
        return self.ceiling_mac_s / self.macs_per_frame

    # ---------- 存储 ----------
    @property
    def weight_kb(self) -> float:
        return self.spec.weight_kb_int8

    @property
    def linebuf_kb(self) -> float:
        """全展开行流水的上界：所有层同时活跃。"""
        return self.spec.linebuf_bytes / 1024

    @property
    def max_layer_linebuf_kb(self) -> float:
        """单层行缓冲最大值——分条带/时分复用的下界。"""
        m = max((l.linebuf_bytes for l in self.spec.layers), default=0)
        return m / 1024

    @property
    def residual_delay_kb(self) -> float:
        return self.spec.residual_delay_bytes() / 1024

    @property
    def onchip_kb(self) -> float:
        """权重 + 行缓冲全展开的上界。"""
        return self.weight_kb + self.linebuf_kb + self.residual_delay_kb

    @property
    def weights_fit_onchip(self) -> bool:
        return self.weight_kb + self.linebuf_kb + self.residual_delay_kb <= self.budget.bram_kb

    # ---------- 带宽 ----------
    @property
    def ddr_mb_s(self) -> float:
        """读一帧输入 + 写一帧输出 + 每帧重载全部权重。"""
        frame = self.target.width * self.target.height * 3  # RGB, 1 字节/通道
        return (2 * frame + self.spec.weight_bytes_int8) * self.target.fps / 1e6

    # ---------- 流水线均衡 ----------
    @property
    def peak_layer_mac_per_pixel(self) -> float:
        """单层每个输出像素的 MAC 数——数值越大说明该层是流水线瓶颈。"""
        best, name = 0.0, ""
        for l in self.spec.layers:
            if l.kind in (UP, DOWN, ADD, ACT) or l.hout * l.wout == 0:
                continue
            v = l.macs / (l.hout * l.wout)
            if v > best:
                best, name = v, l.name
        return best

    @property
    def bottleneck_layer(self) -> str:
        best, name = -1, ""
        for l in self.spec.layers:
            if l.macs > best:
                best, name = l.macs, l.name
        return name

    @property
    def verdict(self) -> str:
        return "PASS" if self.compute_ok else "FAIL"

    # ---------- 输出 ----------
    def summary_row(self) -> str:
        return (
            f"{self.spec.name:<26} {self.spec.params / 1e3:>8.1f}K "
            f"{self.weight_kb:>7.1f}KB {self.macs_per_frame / 1e6:>9.1f}M "
            f"{self.utilization * 100:>7.1f}% "
            f"{'PASS' if self.compute_ok else 'FAIL':>5} "
            f"{self.max_fps:>6.1f}"
        )

    def detail(self) -> str:
        s, t = self.spec, self.target
        lines = [
            f"══ {s.name}  @ {t.name}",
            f"   参数 {s.params:,} ({self.weight_kb:.1f}KB INT8) | "
            f"{self.macs_per_frame:,} MAC/帧 ({self.macs_per_frame * 2 / 1e9:.2f} GFLOP)",
            f"   算力需求 {self.required_mac_s / 1e9:.1f} GMAC/s  vs  天花板 "
            f"{self.ceiling_mac_s / 1e9:.1f} GMAC/s  ->  占用 {self.utilization * 100:.1f}%  "
            f"[{self.verdict}]",
            f"   算力拉满时可跑到 {self.max_fps:.1f} fps",
            f"   片上存储: 权重 {self.weight_kb:.1f} + 行缓冲 "
            f"{self.linebuf_kb:.1f}(全展开上界)/{self.max_layer_linebuf_kb:.1f}(单层) + "
            f"残差延迟 {self.residual_delay_kb:.1f} = {self.onchip_kb:.1f}KB  "
            f"/ 预算 {self.budget.bram_kb:.1f}KB",
            f"   DDR 带宽 {self.ddr_mb_s:.1f} MB/s（权重按帧全量重载）",
            f"   瓶颈层 {self.bottleneck_layer}（{self.peak_layer_mac_per_pixel:.0f} MAC/像素）",
        ]
        return "\n".join(lines)


def analyze(spec: NetSpec, target: Target, budget: Budget, timing: Timing) -> Report:
    return Report(spec=spec, target=target, budget=budget, timing=timing)


def table_header() -> str:
    return (f"{'架构':<26} {'参数':>9} {'权重':>8} {'MAC/帧':>10} "
            f"{'占用率':>8} {'判决':>5} {'极限fps':>7}")


def sweep(factories, targets, budget, timing) -> str:
    """对每个架构 × 每个指标跑一遍，输出总表。

    factories 是 {名字: (h, w) -> NetSpec}。**必须按目标分辨率重新构建网络**——
    拿 640x480 建好的 NetSpec 去评估 720p 目标会得到一模一样的 MAC 数，
    这种错误在表里看起来完全正常，非常难发现。
    """
    out = []
    for tgt in targets:
        out.append(f"\n### {tgt.name}  ({tgt.width}x{tgt.height} @ {tgt.fps}fps)")
        out.append("")
        out.append(table_header())
        out.append("-" * 84)
        for name, make in factories.items():
            spec = make(tgt.height, tgt.width)
            assert (spec.hin, spec.win) == (tgt.height, tgt.width), (
                f"{name} 未按目标分辨率构建：{spec.hin}x{spec.win} != "
                f"{tgt.height}x{tgt.width}"
            )
            out.append(analyze(spec, tgt, budget, timing).summary_row())
    return "\n".join(out)
